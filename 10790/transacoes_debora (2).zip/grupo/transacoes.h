#ifndef TRANSACOES_H
#define TRANSACOES_H

#include <stdbool.h>
#include "../banco.h"

#define SIZE 10

typedef struct
{
    char acao[30];
    float valor;
} Registro;

typedef struct
{
    Registro itens[SIZE];
    int top;
} Pilha;

void inicializarPilha(Pilha *p);
bool estaCheia(Pilha *p);
bool estaVazia(Pilha *p);
void push(Pilha *p, char descricao[], float v);
void mostrarHistorico(Pilha *p);

bool levantar(Conta *c, float valor, Pilha *p);
void depositar(Conta *c, float valor, Pilha *p);
bool transferir(Conta *origem, Conta *destino, float valor, Pilha *p);

#endif
