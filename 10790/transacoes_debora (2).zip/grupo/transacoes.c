#include <stdio.h>
#include <string.h>
#include "transacoes.h"

void inicializarPilha(Pilha *p)
{
    if (p != NULL)
    {
        p->top = -1;
    }
}

bool estaCheia(Pilha *p)
{
    return p != NULL && p->top == SIZE - 1;
}

bool estaVazia(Pilha *p)
{
    return p == NULL || p->top == -1;
}

void push(Pilha *p, char descricao[], float v)
{
    if (p == NULL || estaCheia(p))
        return;

    p->top++;
    strcpy(p->itens[p->top].acao, descricao);
    p->itens[p->top].valor = v;
}

void mostrarHistorico(Pilha *p)
{
    if (p == NULL || estaVazia(p))
    {
        printf("\nSem movimentos.\n");
        return;
    }
    printf("\n--- HISTORICO ---\n");
    for (int i = p->top; i >= 0; i--)
    {
        printf("%s: %.2f EUR\n", p->itens[i].acao, p->itens[i].valor);
    }
}

bool levantar(Conta *c, float valor, Pilha *p)
{
    if (c == NULL || valor <= 0 || c->saldo < valor)
        return false;

    c->saldo -= valor;
    push(p, "Levantamento", -valor);
    return true;
}

void depositar(Conta *c, float valor, Pilha *p)
{
    if (c == NULL || valor <= 0)
        return;

    c->saldo += valor;
    push(p, "Deposito", valor);
}

bool transferir(Conta *origem, Conta *destino, float valor, Pilha *p)
{
    if (origem == NULL || destino == NULL || valor <= 0 || origem->saldo < valor)
    {
        return false;
    }

    origem->saldo -= valor;
    destino->saldo += valor;
    push(p, "Transferencia", -valor);
    return true;
}
