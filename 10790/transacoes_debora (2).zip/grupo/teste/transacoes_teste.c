#include <stdio.h>
#include "transacoes.h"

int main()
{
    Conta contaTeste = {
        .numero_conta = 1001,
        .nome = "Conta Teste",
        .pin_encriptado = 0,
        .saldo = 500.00,
        .next = -1,
        .is_supervisor = false};

    Pilha historico;
    inicializarPilha(&historico);

    printf("--- TESTE MODULO 2 ---\n");
    printf("Saldo Inicial: %.2f EUR\n", contaTeste.saldo);

    levantar(&contaTeste, 100.00, &historico);
    printf("Apos levantar 100 EUR: %.2f EUR\n", contaTeste.saldo);

    depositar(&contaTeste, 50.00, &historico);
    printf("Apos depositar 50 EUR: %.2f EUR\n", contaTeste.saldo);

    mostrarHistorico(&historico);

    return 0;
}
