#include "seguranca/seguranca.h"
#include "gestao_cliente/gestao.h"
#include "interface/interface.h"

#define NUMERO_CONTA_SUPERVISOR 99
#define PIN_SUPERVISOR 1100

static void garantir_supervisor(ListaBanco *lista)
{
    Conta *supervisor = procurar_cliente(lista, NUMERO_CONTA_SUPERVISOR);

    if (supervisor == nullptr)
    {
        inserir_cliente(lista, criar_conta(NUMERO_CONTA_SUPERVISOR, "Supervisor", PIN_SUPERVISOR, 0.0, true));
        return;
    }

    supervisor->pin_encriptado = encriptar_pin(PIN_SUPERVISOR);
    supervisor->is_supervisor = true;
}

int main(void)
{
    ListaBanco lista;
    Conta contas[MAX_CLIENTES];
    int total;

    inicializar_lista(&lista);
    total = ler_clientes(contas, MAX_CLIENTES, FICHEIRO_CLIENTES);

    if (total > 0)
    {
        for (int i = 0; i < total; i++)
        {
            inserir_cliente(&lista, contas[i]);
        }
    }

    garantir_supervisor(&lista);
    guardar_lista_clientes(&lista, FICHEIRO_CLIENTES);

    iniciar_atm(&lista);

    return 0;
}
