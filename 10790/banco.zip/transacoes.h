#ifndef TRANSACOES_H
#define TRANSACOES_H

#include "banco.h"

#define MAX_HISTORICO 10

typedef struct
{
    char descricao[50];
    float valor;
} Movimento;

typedef struct
{
    Movimento movimentos[MAX_HISTORICO];
    int topo;
} Pilha;

void inicializar_pilha(Pilha *p);
void empilhar(Pilha *p, char desc[], float v);
void mostrar_historico(Pilha *p);

bool levantar(Conta *c, float valor, Pilha *p);
void depositar(Conta *c, float valor, Pilha *p);

#endif