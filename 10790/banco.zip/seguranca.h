#ifndef SEGURANCA_H
#define SEGURANCA_H

#include "banco.h"

int encriptar_pin(int pin_original);
bool verificar_login(int pin_inserido, int pin_guardado);
Conta *autenticar(Conta lista[], int total, int num_procurado, int pin_digitado);

void gravar_dados(Conta lista[], int total, int primeiro);
int carregar_dados(Conta lista[], int *primeiro);
void registar_log(int num_conta, char operacao[], float valor);

#endif