#include <stdio.h>
#include <string.h>
#include "transacoes.h"

void inicializar_pilha(Pilha *p)
{
    p->topo = -1;
}

void empilhar(Pilha *p, char desc[], float v)
{
    if (p->topo < MAX_HISTORICO - 1)
    {
        p->topo++;
        strcpy(p->movimentos[p->topo].descricao, desc);
        p->movimentos[p->topo].valor = v;
    }
}

void mostrar_historico(Pilha *p)
{
    if (p->topo == -1)
    {
        printf("\nAinda nao fez movimentos nesta sessao.\n");
        return;
    }
    printf("\n--- ULTIMOS MOVIMENTOS ---\n");
    for (int i = p->topo; i >= 0; i--)
    {
        printf("%s: %.2f EUR\n", p->movimentos[i].descricao, p->movimentos[i].valor);
    }
}

bool levantar(Conta *c, float valor, Pilha *p)
{
    if (valor > 0 && c->saldo >= valor)
    {
        c->saldo -= valor;
        empilhar(p, "Levantamento", -valor);
        return true;
    }
    return false;
}

void depositar(Conta *c, float valor, Pilha *p)
{
    if (valor > 0)
    {
        c->saldo += valor;
        empilhar(p, "Deposito", valor);
    }
}