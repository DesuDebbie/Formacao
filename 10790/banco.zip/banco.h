#ifndef BANCO_H
#define BANCO_H

#include <stdbool.h>

#define MAX_CLIENTES 100
#define CHAVE_REDE 1502

typedef struct
{
    int numero_conta;
    char nome[50];
    int pin_encriptado;
    float saldo;
    int next;
    bool is_supervisor;
} Conta;

#endif