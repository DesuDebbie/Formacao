#include <stdio.h>
#include <stdlib.h>
#include "interface.h"

void limpar_ecran()
{
    printf("\033[H\033[J");
}

void mostrar_menu_inicial()
{
    printf("\033[1;34m");
    printf("==========================================\n");
    printf("          DEBORA BANK - ATM SYSTEM           \n");
    printf("==========================================\n");
    printf("\033[0m"); // Reset
    printf("1. Inserir Cartao (Login)\n");
    printf("2. Sair (Apenas Supervisor)\n");
    printf("\nEscolha uma opcao: ");
}

void mostrar_menu_cliente()
{
    printf("\033[1;32m");
    printf("---------- MENU CLIENTE ----------\n");
    printf("\033[0m");
    printf("1. Levantar Dinheiro\n");
    printf("2. Depositar\n");
    printf("3. Transferir\n");
    printf("4. Consultar Historico (Pilha)\n");
    printf("5. Mudar PIN\n");
    printf("6. Terminar Sessao\n");
    printf("\nOpcao: ");
}

void mostrar_menu_supervisor()
{
    printf("\033[1;35m");
    printf("---------- MENU SUPERVISOR ----------\n");
    printf("\033[0m");
    printf("1. Inserir Novo Cliente\n");
    printf("2. Remover Cliente\n");
    printf("3. Exportar para HTML\n");
    printf("4. Desligar Maquina (Gravar Dados)\n");
    printf("\nOpcao: ");
}
