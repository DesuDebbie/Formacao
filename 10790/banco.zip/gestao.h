#ifndef GESTAO_H
#define GESTAO_H

#include "banco.h"

int inserir_cliente(Conta lista[], int *total, char nome[], int pin, float saldo_inicial, bool supervisor);
void listar_clientes_ordem(Conta lista[], int primeiro_indice);

#endif