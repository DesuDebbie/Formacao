#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "banco.h"
#include "interface.h"
#include "seguranca.h"
#include "gestao.h"
#include "transacoes.h"

int main()
{
    Conta contas[MAX_CLIENTES];
    Conta *utilizador_logado = nullptr;
    Pilha historico_sessao;

    int total_clientes = 0;
    int primeiro_cliente = -1;
    int opcao = 0;
    bool sistema_ligado = true;

    total_clientes = carregar_dados(contas, &primeiro_cliente);

    if (total_clientes == 0)
    {
        primeiro_cliente = inserir_cliente(contas, &total_clientes, &primeiro_cliente, "Admin", 1234, 0.0, true);
    }

    while (sistema_ligado)
    {
        limpar_ecran();

        if (utilizador_logado == nullptr)
        {
            mostrar_menu_inicial();
            if (scanf("%d", &opcao) != 1)
            {
                while (getchar() != '\n')
                    ;
                continue;
            }

            if (opcao == 1)
            {
                int n_conta, p_digitado;
                printf("\n--- LOGIN ---\n");
                printf("Numero de Conta: ");
                scanf("%d", &n_conta);
                printf("PIN: ");
                scanf("%d", &p_digitado);

                utilizador_logado = autenticar(contas, total_clientes, n_conta, p_digitado);

                if (utilizador_logado == nullptr)
                {
                    printf("\n\033[1;31m[Erro] Dados incorretos!\033[0m\n");
                }
                else
                {
                    inicializar_pilha(&historico_sessao);
                    registar_log(utilizador_logado->numero_conta, "LOGIN", 0);
                }
            }
        }
        else
        {
            if (utilizador_logado->is_supervisor)
            {
                mostrar_menu_supervisor();
                if (scanf("%d", &opcao) != 1)
                {
                    while (getchar() != '\n')
                        ;
                    continue;
                }

                if (opcao == 1)
                {
                    char nome[50];
                    int pin;
                    printf("Nome: ");
                    scanf("%s", nome);
                    printf("PIN: ");
                    scanf("%d", &pin);
                    inserir_cliente(contas, &total_clientes, &primeiro_cliente, nome, pin, 0.0, false);
                    registar_log(utilizador_logado->numero_conta, "CRIAR_CLIENTE", 0);
                }
                else if (opcao == 4)
                {
                    gravar_dados(contas, total_clientes, primeiro_cliente);
                    sistema_ligado = false;
                }
            }
            else
            {
                mostrar_menu_cliente();
                if (scanf("%d", &opcao) != 1)
                {
                    while (getchar() != '\n')
                        ;
                    continue;
                }

                if (opcao == 1)
                {
                    float v;
                    printf("Valor a levantar: ");
                    scanf("%f", &v);
                    if (levantar(utilizador_logado, v, &historico_sessao))
                    {
                        registar_log(utilizador_logado->numero_conta, "LEVANTAMENTO", v);
                    }
                    else
                    {
                        printf("Erro no levantamento!\n");
                    }
                }
                else if (opcao == 2)
                {
                    float v;
                    printf("Valor a depositar: ");
                    scanf("%f", &v);
                    depositar(utilizador_logado, v, &historico_sessao);
                    registar_log(utilizador_logado->numero_conta, "DEPOSITO", v);
                }
                else if (opcao == 4)
                {
                    mostrar_historico(&historico_sessao);
                }
                else if (opcao == 6)
                {
                    registar_log(utilizador_logado->numero_conta, "LOGOUT", 0);
                    utilizador_logado = nullptr;
                }
            }
        }

        printf("\nPrima Enter para continuar...");
        while (getchar() != '\n')
            ;
        getchar();
    }

    return 0;
}