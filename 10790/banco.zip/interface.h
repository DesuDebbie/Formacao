#ifndef INTERFACE_H
#define INTERFACE_H

#include "banco.h"

void mostrar_menu_inicial();
void mostrar_menu_cliente();
void mostrar_menu_supervisor();
void limpar_ecran();

#endif