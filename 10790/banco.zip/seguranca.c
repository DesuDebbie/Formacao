#include <stdio.h>
#include <time.h>
#include "seguranca.h"

int encriptar_pin(int pin_original)
{
    return (pin_original * 3) + CHAVE_REDE;
}

bool verificar_login(int pin_inserido, int pin_guardado)
{
    return encriptar_pin(pin_inserido) == pin_guardado;
}

Conta *autenticar(Conta lista[], int total, int num_procurado, int pin_digitado)
{
    for (int i = 0; i < total; i++)
    {
        if (lista[i].numero_conta == num_procurado)
        {
            if (verificar_login(pin_digitado, lista[i].pin_encriptado))
            {
                return &lista[i];
            }
        }
    }
    return nullptr;
}

void gravar_dados(Conta lista[], int total, int primeiro)
{
    FILE *f = fopen("clientes.dat", "wb");
    if (f == nullptr)
        return;

    fwrite(&total, sizeof(int), 1, f);
    fwrite(&primeiro, sizeof(int), 1, f);
    fwrite(lista, sizeof(Conta), total, f);
    fclose(f);
}

int carregar_dados(Conta lista[], int *primeiro)
{
    FILE *f = fopen("clientes.dat", "rb");
    if (f == nullptr)
        return 0;

    int total;
    fread(&total, sizeof(int), 1, f);
    fread(primeiro, sizeof(int), 1, f);
    fread(lista, sizeof(Conta), total, f);
    fclose(f);
    return total;
}

void registar_log(int num_conta, char operacao[], float valor)
{
    FILE *f = fopen("log_operacoes.txt", "a");
    if (f == nullptr)
        return;

    time_t t = time(nullptr);
    struct tm *tm_info = localtime(&t);
    char timestamp[26];
    strftime(timestamp, 26, "%Y-%m-%d %H:%M:%S", tm_info);

    fprintf(f, "[%s] Conta: %d | Op: %s | Valor: %.2f EUR\n", timestamp, num_conta, operacao, valor);
    fclose(f);
}