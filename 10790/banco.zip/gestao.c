#include <stdio.h>
#include <string.h>
#include "gestao.h"
#include "seguranca.h"

int inserir_cliente(Conta lista[], int *total, char nome[], int pin, float saldo_inicial, bool supervisor)
{
    if (*total >= MAX_CLIENTES)
        return -1;

    int novo_indice = *total;
    lista[novo_indice].numero_conta = 1000 + (*total);
    strcpy(lista[novo_indice].nome, nome);
    lista[novo_indice].pin_encriptado = encriptar_pin(pin);
    lista[novo_indice].saldo = saldo_inicial;
    lista[novo_indice].is_supervisor = supervisor;
    lista[novo_indice].next = -1;

    (*total)++;
    return novo_indice;
}

void listar_clientes_ordem(Conta lista[], int primeiro_indice)
{
    int atual = primeiro_indice;
    printf("\n--- LISTA DE CLIENTES ---\n");
    while (atual != -1)
    {
        printf("Nome: %-15s | Conta: %d | Saldo: %10.2f EUR\n",
               lista[atual].nome, lista[atual].numero_conta, lista[atual].saldo);
        atual = lista[atual].next;
    }
}

void exportar_html(Conta lista[], int primeiro)
{
    FILE *f = fopen("relatorio_clientes.html", "w");
    if (f == nullptr)
        return;

    fprintf(f, "<html><head><meta charset='UTF-8'><title>Relatório C23 Bank</title></head><body>");
    fprintf(f, "<h1>Lista de Clientes - C23 Bank</h1>");
    fprintf(f, "<table border='1' cellpadding='10'>");
    fprintf(f, "<tr><th>Conta</th><th>Nome</th><th>Saldo</th><th>Perfil</th></tr>");

    int atual = primeiro;
    while (atual != -1)
    {
        fprintf(f, "<tr>");
        fprintf(f, "<td>%d</td>", lista[atual].numero_conta);
        fprintf(f, "<td>%s</td>", lista[atual].nome);
        fprintf(f, "<td>%.2f EUR</td>", lista[atual].saldo);
        fprintf(f, "<td>%s</td>", lista[atual].is_supervisor ? "Supervisor" : "Cliente");
        fprintf(f, "</tr>");
        atual = lista[atual].next;
    }

    fprintf(f, "</table></body></html>");
    fclose(f);
    printf("\n[Sucesso] Relatorio HTML gerado com nome 'relatorio_clientes.html'\n");
}